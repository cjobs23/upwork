const TelegramBot1 = require('node-telegram-bot-api');
const Gamedig = require('gamedig');

// Підставте свій токен бота з BotFather для першого бота
const botToken1 = '2106699725:AAE8KIdwxw1UVIA1N6Z64yXKB_nHtq2Y-Dk';
const bot1 = new TelegramBot1(botToken1, { polling: true });

// Параметри сервера Battlefield 2
const serverConfig2 = {
  type: 'bf2', // Тип гри (у вашому випадку Battlefield 2)
  host: '91.226.93.158', // IP-адреса другого сервера
  port: 16567, // Порт другого сервера
};

// Зберігайте список гравців для другого сервера
let currentPlayers2 = [];

// Додаємо функцію для отримання інформації з другого сервера BF2
async function getBF2ServerInfo2() {
  try {
    const state = await Gamedig.query(serverConfig2);
    return state;
  } catch (error) {
    console.error('Помилка при отриманні інформації з другого сервера BF2:', error);
    return null;
  }
}

// Додаємо функцію для перевірки другого сервера і сповіщення користувачів
async function checkBF2ServerAndNotify2() {
  const serverInfo = await getBF2ServerInfo2();
  if (serverInfo) {
    const { players, maxplayers, map } = serverInfo;

    const newPlayers = players.filter((player) => !currentPlayers2.includes(player.name));

    if (newPlayers.length > 0) {
      const chatId2 = '-1001560786822'; // ID чату для сповіщень другого сервера
      newPlayers.forEach((newPlayer) => {
        bot1.sendMessage(chatId2, `👤 Игрок ${newPlayer.name} зашел на сервер! 🎮\n🌐 Онлайн: ${players.length}/${maxplayers}\n🗺️ Карта: ${map}`);
      });

      currentPlayers2 = players.map((player) => player.name);
    }
  }
}

// Періодично перевіряємо другий сервер і надсилаємо оновлення (кожну хвилину)
setInterval(checkBF2ServerAndNotify2, 60000);

bot1.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  bot1.sendMessage(chatId, 'Привет!');
});
