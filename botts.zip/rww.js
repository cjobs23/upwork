const TelegramBot1 = require('node-telegram-bot-api');
import('node-fetch').then((fetch) => {
    }).catch((error) => {
    console.error('Помилка при завантаженні модулю node-fetch:', error);
});

// Підставте свій токен бота з BotFather для першого бота
const botToken1 = '1696550733:AAG7rx3aVw6B5Tr08Jd5xJ6oYiWiLD--fGQ';
const bot1 = new TelegramBot1(botToken1, { polling: true });

// Підставте URL другого сервера BF2 JSON
const bf2ServerUrl2 = 'https://api.bflist.io/bf2/v1/servers/37.230.210.130:17568'; 

// Зберігайте список гравців для другого сервера
let currentPlayers2 = [];

// Додаємо ще одну функцію для отримання інформації з другого сервера BF2
async function getBF2ServerInfo2() {
    try {
        const response = await fetch(bf2ServerUrl2);
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Помилка при отриманні інформації з другого сервера BF2:', error);
        return null;
    }
}

// Додаємо ще одну функцію для перевірки другого сервера і сповіщення користувачів
async function checkBF2ServerAndNotify2() {
    const serverInfo = await getBF2ServerInfo2();
    if (serverInfo) {
        const { players, numPlayers, maxPlayers } = serverInfo;

        const newPlayers = players.filter((player) => !currentPlayers2.includes(player.name));

        if (newPlayers.length > 0) {
            const chatId2 = '-1001367117101'; // ID чату для сповіщень другого сервера
            newPlayers.forEach((newPlayer) => {
                bot1.sendMessage(chatId2, `👤 Игрок ${newPlayer.name} зашел на сервер📡!\n🌝 Онлайн: ${numPlayers}/${maxPlayers}\n`);
            });

            currentPlayers2 = players.map((player) => player.name);
        }
    }
}

// Періодично перевіряємо другий сервер і надсилаємо оновлення
setInterval(checkBF2ServerAndNotify2, 100000); // Кожну хвилину (60000 мс)

bot1.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    bot1.sendMessage(
        chatId,
        'Привет ,я делаю мониринг сервера REAL WAR!'
    );
});